// Clase modelo del alumno
// solo tiene el id y el nombre como pide la consigna
public class Alumno {

    private int id;
    private String nombre;

    public Alumno(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // formato que se usa para mostrar y guardar: ID - Nombre
    @Override
    public String toString() {
        return id + " - " + nombre;
    }
}
